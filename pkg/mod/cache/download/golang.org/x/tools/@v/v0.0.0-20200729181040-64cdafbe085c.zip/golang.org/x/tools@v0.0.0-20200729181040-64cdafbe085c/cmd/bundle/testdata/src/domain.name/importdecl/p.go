package importdecl

func F() int { return 1 }
